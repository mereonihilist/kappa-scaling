# κ-Scaling Quantum Measurement Framework

This repository includes LaTeX source, simulation data, and plots for validating the κ-scaling hypothesis.